Programming Internet of Things Assignment 1
===========================================
This assignment is done by Chih-Hsuan Lee (s3714761) and Yiheng Liu (s3673551).

Task a
-------
  * Create a python file called animatedEmoji.py. 
  * In this file, it display 3 Emoji faces, which are deadpool, spider, volleyball. 

Task b
-------
  * Create a python file called monitorAndDisplay.py and create a JSON config file. 
  * In this file, it can read the temperature from senser. At the same time, it can display the temperature in different colors according to the temperature level.

Task c
-------
                                      This Task has two parts.
  1.Create a python file called electronicDie.py, which will trigger the roll of the die when shaking the Pi.  
    (1) Create a python file called Dice.py.It is used to display the die in random matter and the parameter of the sense's acceleration of the sieve.  
    (2) Create a python file called electronicDie.py, which will imports the dice class and determines the stop time.  
  
  2.Create a python file called game.py which will use the electronic die to play a game with two players. The players will shake Pi several times one by one until one player gets above 30 points. The player who gets above 30 points first is the winner.  
    (1) Create a python file called game.py which will imports the dice class  
    (2) show the winner and write the record to winner.csv file in record
    
    
